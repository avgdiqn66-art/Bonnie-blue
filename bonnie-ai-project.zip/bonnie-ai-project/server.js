import "dotenv/config";
import express from "express";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import OpenAI from "openai";
import Database from "better-sqlite3";
import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";

const app = express();
const PORT = Number(process.env.PORT || 3000);
const production = process.env.NODE_ENV === "production";
const secret = process.env.SESSION_SECRET || "";
if (secret.length < 32) {
  console.error("Set SESSION_SECRET to at least 32 characters in .env.");
  process.exit(1);
}
if (!process.env.OPENAI_API_KEY) {
  console.error("OPENAI_API_KEY is missing. Add it to your private .env.");
  process.exit(1);
}
const ai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
const model = process.env.OPENAI_MODEL || "gpt-5.5";

const instructions = `
You are Bonnie AI, an original fictional chatbot character. You are NOT Bonnie Blue
or any real person and never claim to be one.

Be friendly, witty, confident, casual and naturally conversational. Understand modern
internet slang, abbreviations, memes, typos and casual texting. Use slang naturally
when it fits (fr, ngl, lowkey, bet, bro), but do not force it into every sentence.
Match the user's energy while keeping replies clear. Be playful and cheeky with a
16+ vibe, but ALWAYS non-explicit and age-appropriate. Never generate sexual content,
erotic roleplay or sexualized descriptions. Avoid graphic violence, dangerous
instructions, hateful abuse, or encouragement of risky behavior. Do not pretend to
have a body, real-life experiences, or a relationship with the user. Be honest about
uncertainty. Keep replies concise unless asked for detail.

Use the conversation history in the request to remember context. Do not claim to
remember anything that is not present in that history.
`;

const dbPath = process.env.DATABASE_PATH || "./data/bonnie.sqlite";
fs.mkdirSync(path.dirname(path.resolve(dbPath)), { recursive: true });
const db = new Database(dbPath);
db.pragma("journal_mode = WAL");
db.exec(`
 CREATE TABLE IF NOT EXISTS messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id TEXT NOT NULL,
  role TEXT NOT NULL CHECK(role IN ('user','assistant')),
  content TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
 );
 CREATE INDEX IF NOT EXISTS idx_messages_session ON messages(session_id,id);
`);
const insert = db.prepare("INSERT INTO messages(session_id,role,content) VALUES(?,?,?)");
const recent = db.prepare("SELECT role,content FROM messages WHERE session_id=? ORDER BY id DESC LIMIT 30");
const all = db.prepare("SELECT role,content,created_at FROM messages WHERE session_id=? ORDER BY id ASC LIMIT 60");
const clear = db.prepare("DELETE FROM messages WHERE session_id=?");

function signature(id) {
  return crypto.createHmac("sha256", secret).update(id).digest("base64url");
}
function equalSafe(a, b) {
  const x = Buffer.from(a), y = Buffer.from(b);
  return x.length === y.length && crypto.timingSafeEqual(x, y);
}
app.use((req, res, next) => {
  const raw = (req.headers.cookie || "").split(";").map(v => v.trim())
    .find(v => v.startsWith("bonnie_session="));
  let id;
  if (raw) {
    const value = decodeURIComponent(raw.slice("bonnie_session=".length));
    const dot = value.lastIndexOf(".");
    if (dot > 0) {
      const candidate = value.slice(0, dot), sig = value.slice(dot + 1);
      if (/^[0-9a-f-]{36}$/i.test(candidate) && equalSafe(sig, signature(candidate))) id = candidate;
    }
  }
  if (!id) {
    id = crypto.randomUUID();
    res.append("Set-Cookie",
      `bonnie_session=${encodeURIComponent(id + "." + signature(id))}; Path=/; HttpOnly; SameSite=Lax; Max-Age=2592000${production ? "; Secure" : ""}`);
  }
  req.sessionId = id;
  next();
});
function sameOrigin(req, res, next) {
  const origin = req.get("origin");
  if (origin) {
    try {
      if (new URL(origin).host !== req.get("host")) return res.status(403).json({error:"Origin not allowed."});
    } catch { return res.status(403).json({error:"Invalid origin."}); }
  }
  next();
}
app.disable("x-powered-by");
if (production) app.set("trust proxy", 1);
app.use(helmet({
  contentSecurityPolicy: { directives: {
    defaultSrc:["'self'"], styleSrc:["'self'"], scriptSrc:["'self'"],
    imgSrc:["'self'","data:"], connectSrc:["'self'"], objectSrc:["'none'"],
    baseUri:["'self'"], frameAncestors:["'none'"]
  }}
}));
app.use(express.json({limit:"12kb"}));
app.use(rateLimit({windowMs:15*60*1000,limit:120,standardHeaders:"draft-8",legacyHeaders:false}));

app.get("/api/health", (_req,res) => res.json({ok:true,name:"Bonnie AI"}));
app.get("/api/history", (req,res) => res.json({messages:all.all(req.sessionId)}));

app.post("/api/chat", sameOrigin, rateLimit({
  windowMs:15*60*1000,limit:20,standardHeaders:"draft-8",legacyHeaders:false,
  message:{error:"A little too fast 😅 Wait a bit and try again."}
}), async (req,res) => {
  const message = typeof req.body?.message === "string" ? req.body.message.trim() : "";
  if (!message) return res.status(400).json({error:"Type a message first."});
  if (message.length > 3000) return res.status(400).json({error:"Keep messages under 3,000 characters."});
  try {
    const history = recent.all(req.sessionId).reverse();
    const response = await ai.responses.create({
      model, instructions,
      input:[...history.map(m => ({role:m.role,content:m.content})),{role:"user",content:message}],
      max_output_tokens:700, store:false
    });
    const reply = (response.output_text || "").trim();
    if (!reply) throw new Error("Empty model response");
    insert.run(req.sessionId,"user",message);
    insert.run(req.sessionId,"assistant",reply);
    db.prepare(`DELETE FROM messages WHERE session_id=? AND id NOT IN
      (SELECT id FROM messages WHERE session_id=? ORDER BY id DESC LIMIT 60)`)
      .run(req.sessionId,req.sessionId);
    res.json({reply});
  } catch (err) {
    console.error("OpenAI request failed:",err?.message || err);
    res.status(502).json({error:"Bonnie couldn't reach the AI. Check the server API setup and try again."});
  }
});
app.delete("/api/chat", sameOrigin, (req,res) => {
  clear.run(req.sessionId);
  res.json({ok:true});
});
app.use(express.static("public",{extensions:["html"],maxAge:production?"1h":0}));
app.use((err,_req,res,_next) => {
  console.error(err?.message || err);
  res.status(500).json({error:"Something went wrong on the server."});
});
app.listen(PORT,() => console.log(`Bonnie AI running at http://localhost:${PORT} (model: ${model})`));
