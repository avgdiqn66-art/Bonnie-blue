const form=document.querySelector("#form"),input=document.querySelector("#message"),send=document.querySelector("#send");
const messages=document.querySelector("#messages"),welcome=document.querySelector("#welcome"),typing=document.querySelector("#typing"),toast=document.querySelector("#toast");
let busy=false,timer;
function notify(text){toast.textContent=text;toast.classList.add("show");clearTimeout(timer);timer=setTimeout(()=>toast.classList.remove("show"),2600)}
function addMessage(role,content){
 welcome.classList.add("hidden");
 const row=document.createElement("div");row.className=`message ${role}`;
 const avatar=document.createElement("span");avatar.className="avatar";avatar.textContent=role==="assistant"?"B":"Y";
 const bubble=document.createElement("div");bubble.className="bubble";bubble.textContent=content;
 row.append(avatar,bubble);messages.append(row);row.scrollIntoView({behavior:"smooth",block:"end"});
}
async function loadHistory(){try{const r=await fetch("/api/history");if(!r.ok)throw 0;const d=await r.json();(d.messages||[]).forEach(m=>addMessage(m.role,m.content))}catch{notify("Couldn't load saved chat.")}}
async function sendMessage(message){
 if(busy||!message.trim())return;busy=true;send.disabled=true;input.disabled=true;addMessage("user",message);typing.classList.remove("hidden");
 try{const r=await fetch("/api/chat",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({message})});const d=await r.json();if(!r.ok)throw Error(d.error||"Request failed.");addMessage("assistant",d.reply)}
 catch(e){addMessage("assistant",e.message||"I couldn't connect just now. Try again.")}
 finally{typing.classList.add("hidden");busy=false;send.disabled=false;input.disabled=false;input.focus()}
}
form.addEventListener("submit",e=>{e.preventDefault();const value=input.value.trim();if(!value)return;input.value="";input.style.height="auto";sendMessage(value)});
input.addEventListener("input",()=>{input.style.height="auto";input.style.height=Math.min(input.scrollHeight,130)+"px"});
input.addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();form.requestSubmit()}});
document.querySelectorAll(".suggestions button").forEach(b=>b.addEventListener("click",()=>{input.value=b.textContent;form.requestSubmit()}));
async function clearChat(){if(busy)return;try{const r=await fetch("/api/chat",{method:"DELETE"});if(!r.ok)throw 0;messages.replaceChildren();welcome.classList.remove("hidden");notify("New chat started.")}catch{notify("Couldn't clear chat. Try again.")}}
document.querySelector("#new-chat").addEventListener("click",clearChat);document.querySelector("#clear-link").addEventListener("click",clearChat);loadHistory();
